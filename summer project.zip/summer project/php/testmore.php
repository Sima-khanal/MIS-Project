<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Test more</title>
	<style type="text/css">
		body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 20px;
}

h1 {
  text-align: center;
  font-size: 2em;
  margin-bottom: 20px;
}

p {
  text-align: center;
  font-size: 1.2em;
  margin-bottom: 20px;
}

img {
  display: block;
  margin: 0 auto;
  width: 50%;
  max-width: 600px; /* Adjust max-width as needed */
}

ul {
  list-style: none;
  padding: 0;
  margin: 20px auto;
}

li {
  margin-bottom: 10px;
}



	</style>
</head>
<body> 
	<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Unlock Your Potential: Test Preparation Courses</title>
  <link rel="stylesheet" href="style.css"> </head>
<body>
  <h1>Unlock Your Potential: Achieve Success in Test Preparation</h1>
  <p>Ready to take your academic journey to the next level? Our comprehensive test preparation courses empower thousands of students like you to reach their full potential every year.</p>

  <img src="../image/studygroup.png" alt="Students working together in a study session"> <h2>Why Choose Our Courses?</h2>
  <ul>
    <li>Expert Instructors:Learn from experienced instructors who have a proven track record of helping students excel on standardized tests.</li>
    <li>Targeted Learning Materials:Gain access to in-depth study guides, practice tests, and personalized feedback tailored to your needs.</li>
    <li>Flexible Learning Options:Choose from online, in-person, or blended learning formats to fit your schedule and learning style.</li>
    <li>Proven Results: Boost your confidence and score higher with our data-driven approach that has helped countless students achieve their goals.</li>
  </ul>

</body>
</html>


</body>
</html>