<?php
$con = mysqli_connect('localhost', 'root', '', 'summer_project');

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Set the number of results per page
$results_per_page = 5; // Adjust as needed

// Determine the total number of results based on the search query
$search_query = isset($_GET['search']) ? mysqli_real_escape_string($con, $_GET['search']) : '';
$total_results_sql = "SELECT COUNT(*) AS total FROM users WHERE full_name LIKE '%$search_query%'";
$total_results_result = mysqli_query($con, $total_results_sql);
$total_results_row = mysqli_fetch_assoc($total_results_result);
$total_results = $total_results_row['total'];

// Determine the total number of pages
$total_pages = ceil($total_results / $results_per_page);

// Determine the current page
$current_page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
if ($current_page > $total_pages) {
    $current_page = $total_pages;
}
if ($current_page < 1) {
    $current_page = 1;
}

// Determine the starting limit number
$starting_limit = ($current_page - 1) * $results_per_page;
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CRUD Operation</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <style>
        .btn-update {
            background-color: royalblue;
            color: white;
        }
        .btn-update:hover {
            background-color: lightblue;
            color: white;
        }
        .btn-delete {
            background-color: red;
            color: white;
        }
        .btn-delete:hover {
            background-color: indianred;
            color: white;
        }
        .pagination .page-item.active .page-link {
            background-color: seagreen;
            border-color: #007bff;
        }
        .search-bar {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        .search-bar .search-input {
            flex-grow: 1;
        }
        .search-bar .search-button {
            margin-left: 5px;
        }
    </style>
</head>
<body>
<div class="container">
    <h1 class="my-4">Register Student List</h1>
    <div class="search-bar">
        <form class="search-form d-flex" method="GET" action="">
            <input class="form-control search-input" type="text" name="search" placeholder="Search by Student Name" value="<?php echo htmlspecialchars($search_query); ?>">
            <button class="btn btn-primary search-button" type="submit">Search</button>
        </form>
    </div>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">Number</th>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Password</th>
                <th scope="col">Operation</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT * FROM users WHERE full_name LIKE '%$search_query%' LIMIT $starting_limit, $results_per_page";
            $result = mysqli_query($con, $sql);
            if ($result) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $id = $row['id'];
                    $FullName = $row['full_name'];
                    $email = $row['email'];
                    $password = $row['password'];
                    echo '<tr>
                          <th scope="row">'.$id.'</th>
                          <td>'.$FullName.'</td>
                          <td>'.$email.'</td>
                          <td>'.$password.'</td>
                          <td>
                            <a href="update_student.php?updateid='.$id.'" class="btn btn-update text-light me-2">Update</a>
                            <a href="delete_student.php?deleteid='.$id.'" class="btn btn-delete text-light">Delete</a>
                          </td>
                          </tr>';
                }
            }
            ?>
        </tbody>
    </table>
    <!-- Pagination -->
    <nav aria-label="Page navigation">
        <ul class="pagination">
            <?php
            for ($page = 1; $page <= $total_pages; $page++) {
                echo '<li class="page-item'.($page == $current_page ? ' active' : '').'">
                      <a class="page-link" href="?page='.$page.'&search='.urlencode($search_query).'">'.$page.'</a>
                      </li>';
            }
            ?>
        </ul>
    </nav>
     <a href="adminpage.php" class="btn btn-primary">Back</a>
</div>
</body>
</html>
