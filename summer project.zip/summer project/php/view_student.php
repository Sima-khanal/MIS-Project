<?php
$con = mysqli_connect('localhost', 'root', '', 'summer_project');
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Results per page
$results_per_page = 5;
$search_query = isset($_GET['search']) ? mysqli_real_escape_string($con, $_GET['search']) : '';

// Get total user count (filtered)
$total_results_sql = "SELECT COUNT(*) AS total FROM users WHERE full_name LIKE '%$search_query%'";
$total_results_result = mysqli_query($con, $total_results_sql);
$total_results_row = mysqli_fetch_assoc($total_results_result);
$total_results = $total_results_row['total'];

// Pagination setup
$total_pages = ceil($total_results / $results_per_page);
$current_page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$current_page = max(1, min($total_pages, $current_page));
$starting_limit = ($current_page - 1) * $results_per_page;
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Registered Students</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <style>
        .btn-update { background-color: royalblue; color: white; }
        .btn-update:hover { background-color: lightblue; color: white; }
        .btn-delete { background-color: red; color: white; }
        .btn-delete:hover { background-color: indianred; color: white; }
        .pagination .page-item.active .page-link { background-color: seagreen; border-color: #007bff; }
        .search-bar { display: flex; align-items: center; margin-bottom: 20px; }
        .search-bar .search-input { flex-grow: 1; }
        .search-bar .search-button { margin-left: 5px; }
        .course-list { font-size: 0.9rem; color: #555; }
    </style>
</head>
<body>
<div class="container">
    <h1 class="my-4">Registered Student List</h1>

    <div class="search-bar">
        <form class="search-form d-flex" method="GET" action="">
            <input class="form-control search-input" type="text" name="search" placeholder="Search by Student Name" value="<?php echo htmlspecialchars($search_query); ?>">
            <button class="btn btn-primary search-button" type="submit">Search</button>
        </form>
    </div>

    <table class="table table-bordered table-hover">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Enrolled Courses</th>
                <th>Operation</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $sql = "SELECT * FROM users WHERE full_name LIKE '%$search_query%' LIMIT $starting_limit, $results_per_page";
        $result = mysqli_query($con, $sql);

        if ($result && mysqli_num_rows($result) > 0) {
            while ($user = mysqli_fetch_assoc($result)) {
                $user_id = $user['id'];
                $name = $user['full_name'];
                $email = $user['email'];

                // Get enrolled courses for the user
                $courses_sql = "SELECT course_name, status FROM enroll WHERE id='$user_id'";
                $courses_result = mysqli_query($con, $courses_sql);

                $courses = [];
                while ($course = mysqli_fetch_assoc($courses_result)) {
                    $courses[] = $course['course_name'] . ' (' . $course['status'] . ')';
                }

                echo '<tr>
                        <td>' . $user_id . '</td>
                        <td>' . htmlspecialchars($name) . '</td>
                        <td>' . htmlspecialchars($email) . '</td>
                        <td class="course-list">' . (!empty($courses) ? implode(', ', $courses) : 'No courses enrolled') . '</td>
                        <td>
                            <a href="update_student.php?updateid=' . $user_id . '" class="btn btn-update me-2">Update</a>
                            <a href="delete_student.php?deleteid=' . $user_id . '" class="btn btn-delete">Delete</a>
                        </td>
                      </tr>';
            }
        } else {
            echo '<tr><td colspan="5" class="text-center">No users found.</td></tr>';
        }
        ?>
        </tbody>
    </table>

    <!-- Pagination -->
    <nav aria-label="Page navigation">
        <ul class="pagination">
            <?php
            for ($page = 1; $page <= $total_pages; $page++) {
                echo '<li class="page-item' . ($page == $current_page ? ' active' : '') . '">
                        <a class="page-link" href="?page=' . $page . '&search=' . urlencode($search_query) . '">' . $page . '</a>
                      </li>';
            }
            ?>
        </ul>
    </nav>

    <a href="adminpage.php" class="btn btn-primary mt-3">Back</a>
</div>
</body>
</html>
