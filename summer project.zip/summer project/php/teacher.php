<?php 
session_start();

$message = "";
if (isset($_POST['submit'])) {
    $con = mysqli_connect('localhost', 'root', '', 'summer_project') or die('unable to connect');
    $username = $_POST['username'];
    $t_password = $_POST['pass'];

    $sql = "SELECT * FROM teacher WHERE t_name = ?";
    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        if ($t_password == $row["t_password"]) {
            $_SESSION['t_id'] = $row['t_id'];
            $_SESSION['t_name'] = $row['t_name'];
            header("location:teacherdashboard.php");
            exit();
        } else {
            $error[] = 'Wrong Username or password!';
        }
    } else {
        $error[] = 'Teacher not found!';
    }
    mysqli_close($con);
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login Page</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <style type="text/css">
        .container {
            max-width: 500px;
            margin: 0 auto;
            padding: 120px;
            background-color: orange;
        }

        .form-group {
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <div class="container">
        <form action="#" method="post">
            <div class="logo">
                <img src="../image/RAIN.png" class="img-fluid" alt="logo" style="width: 50%;">
            </div>
            <h1>Teacher Login</h1>
            <?php
                if(isset($error)){
                    foreach($error as $err){
                        echo '<span class="error-msg">'.$err.'</span>';
                    }
                }
            ?>
            <div class="form-group">
                <label>Email / Username</label><br>
                <input type="text" class="form-control" name="username" required placeholder="Enter username">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" class="form-control" name="pass" required placeholder="Enter password">
            </div>
            <input class="btn btn-primary" type="submit" name="submit" value="Login">
        </form>
    </div>
</body>
</html>
