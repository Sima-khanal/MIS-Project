<?php
session_start();

if (!isset($_SESSION['s_id'])) {
    header('Location: signup.php');
    exit();
}

if (!isset($_GET['enroll_id']) || !is_numeric($_GET['enroll_id'])) {
    die("Invalid enrollment ID.");
}

$enroll_id = intval($_GET['enroll_id']);
$user_id = $_SESSION['s_id'];

$con = mysqli_connect('localhost', 'root', '', 'summer_project');
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Verify enrollment belongs to logged-in user and status != completed
$sql = "SELECT status FROM enroll WHERE enroll_id = '$enroll_id' AND id = '$user_id' LIMIT 1";
$result = mysqli_query($con, $sql);

if ($result && mysqli_num_rows($result) == 1) {
    $enroll = mysqli_fetch_assoc($result);
    if (strtolower($enroll['status']) === 'completed') {
        die("You cannot cancel a completed enrollment.");
    } else {
        // Proceed to delete enrollment
        $del_sql = "DELETE FROM enroll WHERE enroll_id = '$enroll_id' AND id = '$user_id'";
        if (mysqli_query($con, $del_sql)) {
            header("Location: user_profile.php?msg=Enrollment cancelled successfully");
            exit();
        } else {
            die("Error cancelling enrollment: " . mysqli_error($con));
        }
    }
} else {
    die("Enrollment not found or you do not have permission to cancel it.");
}
?>
