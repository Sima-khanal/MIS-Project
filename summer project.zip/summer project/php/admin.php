<?php 

session_start();
 

$message="";
if (isset($_POST['submit'])) {
	$con = mysqli_connect('localhost','root','','summer_project') or die('unable to connect');
	$username = $_POST['username'];
	$password = $_POST['pass'];

	$sql = "SELECT * FROM admin WHERE name = '$username'";

	$result = mysqli_query($con,$sql);
	$row = mysqli_fetch_assoc($result);
	if ($password == $row["password"]) {
		if (is_array($row)) {
			$_SESSION['id'] = $row['id'];
			$_SESSION['name'] = $row['name'];
		} 
	}
	else {
		$error[] = 'Wrong Username or password!';
	}
} 

if (isset($_SESSION['id'])) {
	header("location:adminpage.php");
	exit();
}  
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login Page</title>
	  <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
	
	<style type="text/css">
		
		/*body {*/
   /* margin: 0;
    padding: 0;
    background:lavenderblush;
}
.login-box {
    width: 280px;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%,-50%);
    background: #fff;
    padding: 40px;
    text-align: center;
}*/    .h1 {
            height: 90px;
            width: 100px;
        }

        .container {
            max-width: 500px;
            margin: 0 auto;
            padding: 120px;
            background-color: orange;
           
        }

        .form-group {
            margin-bottom: 30px;
        }
		   
		

	</style>
	
</head>
<body>

	     <div class="container">
	    	<form action="#" method="post">
			 <div class="logo">
             <img src="../image/RAIN.png" class="img-fluid" alt="logo"  style="width: 50%;">
             </div>
			<h1>Admin Login</h1>
			<?php
				if(isset($error)){
					foreach($error as $error){
						echo '<span class="error-msg">'.$error.'</span>';
					};
				};
			?>
			<div class="form-group">
			<label>Email / Username</label><br>
			<input type="text"  class="form-control" name="username" required placeholder="Enter username">
		    </div>
			<div class="form-group">
			<label>Password</label>
			<input type="password" class="form-control"  name="pass" required placeholder="Enter password">		
			<input class="btn btn-primary" type="submit" name="submit" value="Login">
		    </div>
		</form>
	</div>
</body>
</html>