<?php
session_start();
if (!isset($_SESSION['name']) ) {
    header('location:admin.php');
    exit(); // Ensure script execution stops after redirect
}


$con = mysqli_connect('localhost', 'root', '', 'summer_project');

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}


// Query to retrieve enrolled courses for the current user with additional details
$select_enroll = "SELECT enroll_id, course_id, id, course_name, fee, s_date, e_date,invoice_no,status FROM enroll";
$result_enroll = mysqli_query($con, $select_enroll);

if (!$result_enroll) {
    die("Error receiving data: " . mysqli_error($con));
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>View Enrollments</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: whitesmoke;
        }
        h2 {
            text-align: center;
            margin-top: 30px;
            margin-bottom: 20px;
            color: #333;
        }
        table {
            width: 80%;
            margin: 0 auto;
            border-collapse: collapse;
            background-color: whitesmoke;
        }
        table, th, td {
            border: 1px solid goldenrod;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: orange;
        }
        tr:hover {
            background-color: papayawhip;
        }
    a.btn.btn-primary {
        display: inline-block;
        padding: 10px 20px;
        margin-left: 20px;
        text-decoration: none;
        color: white;
        background-color: blue;
        border: none;
        border-radius: 5px;
        transition: background-color 0.3s;
    }

    a.btn.btn-primary:hover {
        background-color: white;
        color: black;
    }
    </style>
</head>
<body>
    <h2>Enrolled Courses</h2>
    <table>
        <thead>
            <tr>
                <th>Enroll ID</th>
                <th>Course ID</th>
                <th>Student ID</th>
                <th>Course Name</th>
                <th>Fee</th>
                <th>start_Date</th>
                  <th>End_Date</th>
                  <th>Invoice_No</th>
                  <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
            while ($row = mysqli_fetch_assoc($result_enroll)) {
                echo "<tr>";
                echo "<td>" . $row['enroll_id'] . "</td>";
                echo "<td>" . $row['course_id'] . "</td>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['course_name'] . "</td>";
                echo "<td>" . $row['fee'] . "</td>";
                echo "<td>" . $row['s_date'] . "</td>";
                echo "<td>" . $row['e_date'] . "</td>";
                 echo "<td>" . $row['invoice_no'] . "</td>";
                  echo "<td>" . $row['status'] . "</td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
     <a href="adminpage.php" class="btn btn-primary">Back</a>
</body>
</html>
