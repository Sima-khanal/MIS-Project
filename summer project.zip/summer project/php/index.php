<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <title>web</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <style type="text/css">
        .footer {
            background-color: royalblue;
            color: white;
            padding: 10px;
            text-align: center;
            position: relative;
            width: 100%;
        }
        .footer .contact-info {
            display: flex;
            justify-content: center;
            gap: 20px;
            align-items: center;
            flex-wrap: wrap;
        }
        .footer .contact-info i {
            margin-right: 5px;
        } 
    </style>
    
</head>
<body>
    <div class="banner">
        <div class="navbar">
            <img src="../image/RAIN.png" class="logo">  
            <ul>
                <li><a class="active" href="#">HOME</a></li>
                <li><a href="view_course.php">COURSES</a></li> 
                <li><a href="aboutus.php">ABOUT US</a></li>
                <li><a href="signup.php">SIGNUP</a></li>
            </ul>
        </div>
    </div>
 
    <div class="content">
        <h1>DESIGN YOUR DREAM</h1>
        <p>-Sharing what we have by creating moments of joy that last a lifetime</p>
        <a class="one" href="signin.php">Sign in</a>
    </div>
  
    <div class="container">
        <h1>Why us?</h1>
        <div class="row">
            <div class="service">
                <h2>Course Search</h2>
                <p>Thousands of students choose to study with us every year and they have achieved great success. Join our test preparation courses and grow your real potentials!</p>
                <a class="one" href="testmore.php">Know More</a>
            </div>
            <div class="service">
                <h2>Benefits </h2>
                <p>Our platform gives you the luxury of practice from the comfort of your home and our E-testing Center gives you access to tests from the comfort of your home.</p>
                <a class="one" href="E-test.php">Know More</a>
            </div>
            <div class="service">
                <h2>Abroad Study</h2>
                <p>Once the students have sat for their final exam at various local testing centers and also our counsels prospective students for their higher education in foreign countries.</p>
                <a class="one" href="abroad.php">Know More</a>
            </div>
        </div>
     </div>
     <div class="footer">
        <div class="contact-info">
            <span><i class="fas fa-map-marker-alt"></i> Putalisadak, Kathmandu, Nepal</span>
            <span><i class="fas fa-phone"></i> +977 01 4011052 | +977 01 401745</span>
            <span><i class="fas fa-envelope"></i> info@raineduaction.edu.np</span>
        </div>
    </div>
</body>
</html>
</html>