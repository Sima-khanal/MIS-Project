<?php
if (isset($_POST['submit'])) {

         $fullName = $_POST['fullname'];
         $email = $_POST['email'];
         $password = $_POST['password'];
         $passwordRepeat = $_POST['repeat_password'];
         $passwordHash = md5($password);
         $errors = array();
         
         if (empty($fullName) OR empty($email) OR empty($password) OR empty($passwordRepeat)) {
            array_push($errors, "All fields are required");
         }
         if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
             array_push($errors, "Email is not valid");
         }
         if (strlen($password) < 8) {
            array_push($errors, "Password must be at least 8 characters");
         }
         if ($password != $passwordRepeat) {
            array_push($errors, "Passwords do not match");
         }

         $con = mysqli_connect('localhost', 'root', '', 'summer_project');
         if (!$con) {
            die("Connection failed: " . mysqli_connect_error());
         }
       
         $sql = "SELECT * FROM users WHERE email = '$email'";
         $result = mysqli_query($con, $sql);
         $rowCount = mysqli_num_rows($result);
         if ($rowCount > 0) {
            array_push($errors, "Email already exists!");
         }

         if (count($errors) > 0) {
            foreach ($errors as $error) {
               echo "<div class='alert alert-danger'>$error</div>";
            }
         } else {
            $sql1 = "INSERT INTO users (full_name, email, password) VALUES ('$fullName', '$email', '$passwordHash')";

            if (mysqli_query($con, $sql1)) {
                header("location: signin.php");
                echo "<div class='alert alert-success'>You are registered successfully</div>";
            } else {
                die("Something went wrong");
            }
         }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Signup</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">      
    <style type="text/css">
        .h1 {
            height: 100px;
            width: 200px;
        }

        .container {
            max-width: 500px;
            margin: 0 auto;
            padding: 120px;
            background-color: orange;
        }

        .form-group {
            margin-bottom: 30px;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="logo">
            <img src="../image/RAIN.png" class="img-fluid" alt="logo" style="width: 50%;">
        </div>
        
        <form action="signup.php" method="post">
            <div class="form-group">
                <input type="text" class="form-control" name="fullname" placeholder="Full Name:">
            </div>
            <div class="form-group">
                <input type="email"  class="form-control" name="email" placeholder="Email:">
            </div>
            <div class="form-group">
                <input type="password"  class="form-control" name="password" placeholder="Password:">
            </div>
            <div class="form-group">
                <input type="text"  class="form-control" name="repeat_password" placeholder="Repeat Password:">
            </div>
            <div class="form-btn">
                <input type="submit" class="btn btn-primary" value="Sign-Up" name="submit">
            </div>
            <div class="text-center mt-3">
                <a href="signin.php">Already have an account?</a>
            </div>
        </form>
    </div>
</body>
</html>3