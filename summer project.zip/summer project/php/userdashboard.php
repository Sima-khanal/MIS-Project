<?php
session_start();
if (!isset($_SESSION['s_name'])) {
    header('location:signup.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> 
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <style type="text/css">
           * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: sans-serif;
        }
        body {
            min-height: 100vh;
        }
        li {
            list-style: none;
        }
        a {
            text-decoration: none;
        }
        .btn {
            background: blue;
            color: white;
            padding: 10px 15px; /* Increased padding */
            text-align: center;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-bottom: 10px; /* Added margin between buttons */
        }
        .btn:hover {
            background: white;
            color: blue;
            border: 2px solid crimson;
        }
        .sidebar {
            position: fixed;
            background: red;
            width: 250px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .sidebar .logo-name {
            height: 80px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .sidebar ul {
            padding-left: 0;
        }
        .sidebar li {
            font-size: 18px;
            margin-top: 20px;
            padding: 10px 20px;
            display: flex;
            align-items: center;
            color: white;
        }
        .sidebar li:hover {
            background: mintcream;
            color: white;
        } 
        .container {
            margin-left: 250px;
            padding: 20px;
        }
        .container .header {
            position: fixed;
            top: 0;
            width: calc(100% - 250px);
            height: 80px;
            background: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0.5, 0.1);
        }
        .container .header .nav {
            display: flex;
            align-items: center;
        }
        .container .header .nav .user .btn {
            display: flex;
            align-items: center;
            margin-left: auto;
        }
  
      
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <div class="logo-name">
                <img src="../image/RAIN.png" class="img-fluid" alt="logo" style="width: 80%;"> 
            </div>
        </div>
        <ul class="menu">
            <li>
                <a href="#">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li>
                <a href="user_profile.php">
                    <i class="fas fa-user"></i>
                    <span>Profile</span>
                </a>
            </li>
            <li>
                <a href="view_course.php">
                    <i class="fas fa-book"></i>
                    <span>Courses</span>
                </a>
            </li>
            <li>
                <a href="user_logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>
  
    <div class="container">
        <div class="header">
            <div class="nav">
                <div class="user">
                    <h1>Welcome, <?php echo $_SESSION['s_name']; ?></h1>
                </div>
            </div>
            <div class="user">
                <a href="index.php" class="btn">Home</a>
            </div>
        </div>
      
</body>
</html>