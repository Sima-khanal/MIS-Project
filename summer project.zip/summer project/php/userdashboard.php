<?php
session_start();
if (!isset($_SESSION['s_name'])) {
    header('location:signup.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> 
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <style type="text/css">
           * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: sans-serif;
        }
        body {
            min-height: 100vh;
        }
        li {
            list-style: none;
        }
        a {
            text-decoration: none;
        }
        .btn {
            background: blue;
            color: white;
            padding: 10px 15px; /* Increased padding */
            text-align: center;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-bottom: 10px; /* Added margin between buttons */
        }
        .btn:hover {
            background: white;
            color: blue;
            border: 2px solid crimson;
        }
        .sidebar {
            position: fixed;
            background: red;
            width: 250px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .sidebar .logo-name {
            height: 80px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .sidebar ul {
            padding-left: 0;
        }
        .sidebar li {
            font-size: 18px;
            margin-top: 20px;
            padding: 10px 20px;
            display: flex;
            align-items: center;
            color: white;
        }
        .sidebar li:hover {
            background: mintcream;
            color: white;
        } 
        .container {
            margin-left: 250px;
            padding: 20px;
        }
        .container .header {
            position: fixed;
            top: 0;
            width: calc(100% - 250px);
            height: 80px;
            background: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0.5, 0.1);
        }
        .container .header .nav {
            display: flex;
            align-items: center;
        }
        .container .header .nav .user .btn {
            display: flex;
            align-items: center;
            margin-left: auto;
        }
  
      
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <div class="logo-name">
                <img src="../image/RAIN.png" class="img-fluid" alt="logo" style="width: 80%;"> 
            </div>
        </div>
        <ul class="menu">
            <li>
                <a href="#">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li>
                <a href="user_profile.php">
                    <i class="fas fa-user"></i>
                    <span>Profile</span>
                </a>
            </li>
            <li>
                <a href="view_course.php">
                    <i class="fas fa-book"></i>
                    <span>Courses</span>
                </a>
            </li>
            <li>
                <a href="user_logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>
  
    <div class="container">
        <div class="header">
            <div class="nav">
                <div class="user">
                    <h1>Welcome, <?php echo $_SESSION['s_name']; ?></h1>
                </div>
            </div>
            <div class="user">
                <a href="index.php" class="btn">Home</a>
            </div>
        </div>
      <div style="margin-top: 100px;">  <!-- to clear fixed header height -->

    <section class="dashboard-intro mb-4" style="padding: 20px; background: #fff; border-radius: 10px; box-shadow: 0 0 15px rgba(0,0,0,0.05);">
        <h2>Hello, <span style="color: #007bff;"><?php echo htmlspecialchars($_SESSION['s_name']); ?></span>! Ready to learn something new today?</h2>
        <p style="font-style: italic; color: #555;">“Education is the most powerful weapon which you can use to change the world.” – Nelson Mandela</p>
    </section>

   <section class="system-info" style="margin-bottom: 30px; background: #fff; padding: 30px; border-radius: 10px; box-shadow: 0 0 15px rgba(0,0,0,0.05);">
    <h2 style="color: #333; margin-bottom: 15px;">About This Learning Portal</h2>
    <p style="font-size: 16px; color: #555;">
        Welcome to our online learning platform designed exclusively for students and instructors to connect, collaborate, and grow.
        This system helps you:
    </p>
    <ul style="margin-top: 15px; color: #444; font-size: 15px;">
        <li>✔ Enroll in diverse courses designed to boost your skills and knowledge</li>
        <li>✔ Track your enrollment status and course schedules in one place</li>
        <li>✔ Access course content, schedules, and instructor details with ease</li>
        <li>✔ Stay informed with updates, deadlines, and progress tracking</li>
        <li>✔ Manage your profile and view your learning journey at any time</li>
    </ul>
    <p style="margin-top: 20px; font-size: 15px; color: #555;">
        Whether you're just starting out or enhancing your expertise, this platform ensures a structured and user-friendly environment to support your learning.
    </p>
</section>

    <section class="quick-actions" style="background: #fff; padding: 20px; border-radius: 10px; box-shadow: 0 0 15px rgba(0,0,0,0.05);">
        <h3>Quick Actions</h3>
        <div class="d-flex gap-3 flex-wrap" style="margin-top: 10px;">
            <a href="view_course.php" class="btn btn-primary flex-grow-1 flex-md-grow-0" style="min-width: 150px;">View Courses</a>
            <a href="user_profile.php" class="btn btn-success flex-grow-1 flex-md-grow-0" style="min-width: 150px;">Edit Profile</a>
        </div>
    </section>

    <section class="recent-activity mt-5" style="background: #fff; padding: 20px; border-radius: 10px; box-shadow: 0 0 15px rgba(0,0,0,0.05);">
        <h3>Recent Activity</h3>
        <ul style="list-style: none; padding-left: 0; color: #555;">
            <li>✔ Enrolled in <strong>Full Stack Web Development</strong> course</li>
            <li>⌛ Assignment for <strong>JavaScript Basics</strong> due in 3 days</li>
            <li>⭐ Completed <strong>HTML & CSS Fundamentals</strong> course</li>
        </ul>
    </section>

</div>
<footer style="background-color: #343a40; color: white; padding: 10px 20px;">
    <div class="container d-flex justify-content-between align-items-center flex-wrap" style="font-size: 14px;">
        
        <!-- Left: System Name -->
        <div style="flex: 1; text-align: left;">
            <strong>RAIN Learning Platform</strong>
        </div>

        <!-- Center: Copyright -->
        <div style="flex: 1; text-align: center;">
            &copy; <?php echo date("Y"); ?> Summer Project. All rights reserved.
        </div>

        <!-- Right: Social Icons -->
        <div style="flex: 1; text-align: right;">
            <a href="#" style="color: white; margin-left: 10px;">
                <i class="fab fa-facebook-f"></i>
            </a>
            <a href="#" style="color: white; margin-left: 10px;">
                <i class="fab fa-twitter"></i>
            </a>
            <a href="#" style="color: white; margin-left: 10px;">
                <i class="fab fa-instagram"></i>
            </a>
            <a href="mailto:info@example.com" style="color: white; margin-left: 10px;">
                <i class="fas fa-envelope"></i>
            </a>
        </div>

    </div>
</footer>

</body>

</html>