<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Contact</title>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
	<style type="text/css">
		#social-media
{  
	background: lavenderblush;
	padding: 100px 0;
	font-weight: 200px;
	height: 80px;
	width: 100%;
}
#social-media p{
	font-size:30px;
	font-weight: 100;
	margin-bottom: 30px;
	text-align: center;
}
.social-icons{
	height: 10vh;
	display: flex;
	justify-content: center;
	align-items: center;

}
 .social-icons a{
	height: 100px;
	width: 100px;
	background-color:lavender;
	border-radius: 50px;
	margin: 10px;
	line-height: 120px;
	box-shadow: 1px 4px 2px 2px lightblue;
}
 a i{
 transition: all 0.3s linear;
}
 a:hover i{
	transform: scale(1.4);
}
.fa-facebook{
	color: blue;
}
.fa-instagram{
	color: red;
}
.fa-twitter{
	color:royalblue;

}
/*#footer{
background color: yellow;

}
.footer-box{
	padding: 20px;
}
.footer-box .fa{
	margin-right: 8px;
	font-size: 25px;
	height: 40px;
	width: 40px;
	text-align: center;
	padding-top:7px ;
	border-radius: 2px;
	background color: green;
}*/
contactForm{
	width: 20%;
	padding: 30px;
}
.contactForm h2{
	font-size: 30px;
	color: Black;
	font-weight: 300;

}

	</style>
</head>
<body>
	<!-----------------------Social Media section ---------------------->
   <section id="social-media">
    <div class="container text-center">
    	
   <p>Find us on social media</p> 
  
    <div class="social-icons">
    	<a href="https://www.facebook.com"><i class="fa-brands fa-3x fa-facebook"></i></a>
    	<a href="https://www.instagram.com"><i class="fa-brands fa-3x fa-instagram"></i></a>
    	<a href="https://www.twitter.com"><i class="fa-brands fa-3x fa-twitter"></i></a>
     </div>
     </div>
     </section>

     <!--------footer section--------->
     <section id="footer">
     	<div class="container">
     		<div class="row">
    		<div class="col-md-4 footer-box">
    			<p><b>Location Details</b></p>
    			<p><i class="fa-light fa-location-dot"></i>Newroad,Pokhara</p>
    			<p><i class="fa-light fa-phone"></i>01-54313067,9814567933</p>
    			<p><i class="fa-light fa-envelope"></i>legacy32@gmail.com</p>
    			<p>Sunday to Friday
             7:00 am - 6:00 pm</p>
    				
    		</div>
    </section>


</body>
</html>