<?php

$errors = [];

if(isset($_GET['deleteid'])) {
    $id = $_GET['deleteid'];
} else {
    $errors[] = "Invalid course ID.";
}

if(empty($errors)) {
    // Connect to the database
    $con = mysqli_connect('localhost', 'root', '', 'summer_project');

    // Check connection
    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Prepare and bind the SQL statement
    $stmt = $con->prepare("DELETE FROM course WHERE course_id=?");
    $stmt->bind_param("i", $id);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Course deleted successfully";
        header('location:crud_course.php');
        exit; // terminate the script after redirection
    } else {
        $errors[] = 'Error deleting data: ' . $stmt->error;
    }
    $stmt->close();
    mysqli_close($con);
}

if (!empty($errors)) {
    foreach($errors as $err){
        echo '<span class="error-msg">' . $err . '</span>';
    }
}
?>