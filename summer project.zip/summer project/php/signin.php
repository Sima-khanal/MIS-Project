<?php
    session_start();
       	if(isset($_POST["submit"])){
       		$con = mysqli_connect('localhost','root','','summer_project') or die('unable to connect');
			
       		$email =$_POST["email"];
       		$passowrd =$_POST["password"];
       		$sql ="SELECT * FROM users WHERE email ='$email' ";
       		$result=mysqli_query($con,$sql);
       		$user =mysqli_fetch_assoc($result);

       		if($user){
         
       			if (md5($passowrd) == $user['password']) {
             	
                    if (is_array($user)) {
                        $_SESSION['s_id'] = $user['id'];
                        $_SESSION['s_name'] = $user['full_name'];
                    }
             }
             else{
       			echo "<div class='alert alert-danger'>Password does not match</div>";
         	
          	} 
            }
       		else{
       			echo "<div class='alert alert-danger'>Email does not match</div>";
         	
          	}      	
         }
           if (isset($_SESSION['s_id'])) {
            header("Location:userdashboard.php");
             exit();
         }   

       	?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Signin form</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">   	
        <style type="text/css">
		   
			.container {
            max-width: 500px;
            margin: 0 auto;
            padding: 120px;
            background-color: orange;
        }

        .form-group {
            margin-bottom: 10px;
        }
		</style>
           </head>
           <body>
       <div class="container">
       	 <div class="logo">
             <img src="../image/RAIN.png" class="img-fluid" alt="logo"  style="width: 50%;">
             </div>

       	<form action="signin.php" method="post">
       		<div class="form-group">
       			<input type="email" placeholder="Enter Email:" name="email" class="form-control">
       		</div>
       		<div class="form-group">
       			<input type="password" placeholder="Enter Password:" name="password" class="form-control">
       		</div>
       		<div class="form-btn">
       			<input type="submit" name="submit" value="submit" class="btn btn-primary">
       		</div>
       	</form>
       </div>
</body>
</html>