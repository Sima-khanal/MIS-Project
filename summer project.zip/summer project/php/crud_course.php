<?php
// Function to fetch all courses
function getCourses($con) {
    $sql = "SELECT * FROM course";
    $result = mysqli_query($con, $sql);

    $courses = [];

    if ($result && mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
            $courses[] = $row;
        }
    }

    return $courses;
}

$con = mysqli_connect('localhost', 'root', '', 'summer_project');
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>View Courses</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> 
    <style type="text/css">
        .h4 {
            height: 100px;
            width: 200px;
        }

        .Login {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px; 
            background-color: white;
        }

        .form-group {
            margin-bottom: 20px; 
        }

        .btn-group {
            display: flex;
            align-items: center;
        }

        .btn-group .btn {
            margin-right: 5px;
        }
    </style>   
</head>
<body>
    <div class="Login">
        <h4>Courses</h4>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Fee</th>
                    <th>Description</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $courses = getCourses($con);
                foreach($courses as $course) {
                    echo "<tr>";
                    echo "<td>" . (isset($course['course_id']) ? $course['course_id'] : '') . "</td>"; // compare
                    echo "<td>" . (isset($course['name']) ? $course['name'] : '') . "</td>";
                    echo "<td>" . (isset($course['fee']) ? $course['fee'] : '') . "</td>";
                    echo "<td>" . (isset($course['course_desp']) ? $course['course_desp'] : '') . "</td>";
                    echo "<td class='btn-group'>
                                   <button class='btn btn-primary'><a href='update_course.php?updateid=" . (isset($course['course_id']) ? $course['course_id'] : '') . "' class='text-light'>Update</a></button>
                            <button class='btn btn-danger'><a href='delete_course.php?deleteid=" . (isset($course['course_id']) ? $course['course_id'] : '') . "' class='text-light'>Delete</a></button>
                          </td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
         <a href="adminpage.php" class="btn btn-primary">Back</a>
    </div>
</body>
</html>

<?php
mysqli_close($con);
?>