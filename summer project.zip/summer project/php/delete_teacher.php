<?php
$con = mysqli_connect('localhost', 'root', '', 'summer_project');
if(!$con){
    die("Connection failed: " . mysqli_connect_error());
}

if(isset($_GET['deleteid'])) { 
    $id = $_GET['deleteid'];
    
    $sql = "DELETE FROM teacher WHERE t_id='$id'";
    $result = mysqli_query($con, $sql);

    if($result){
        if (mysqli_affected_rows($con) == 1) {
            header('location:view_teacher.php');
            exit;
        } else {
            echo "No records were deleted.";
        }
    } else {
        echo "Error: " . mysqli_error($con);
    }
}
?>