<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <title>About Us - Rain Education Consultancy</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        .about-section, .counselling-section {
            padding: 50px;
            padding-right: 30%;
            text-align: left;
        }
        .about-section:nth-child(even) {
            background-color: light orange; 
        }
        .about-section:nth-child(odd), .counselling-section {
            background-color: floralwhite;
        }
        .about-content, .counselling-content {
            max-width: 800px;
            margin: auto;
        }
         .testimonials {
            padding: 50px;
            text-align: left;
        }
       
        .testimonials {
            background-color: lightgoldenrodyellow; 
        }
        
        .testimonials .testimonial {
            margin-bottom: 20px;
        }
        .counselling-content a {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: royalblue;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .footer {
            background-color: royalblue;
            color: white;
            padding: 10px;
            text-align: center;
            position: relative;
            width: 100%;
        }
        .footer .contact-info {
            display: flex;
            justify-content: center;
            gap: 20px;
            align-items: center;
            flex-wrap: wrap;
        }
        .footer .contact-info i {
            margin-right: 5px;
        }
    </style>
</head>
<body>
    <div class="about-section">
        <div class="about-content">
            <h1>About Rain Education Consultancy</h1>
            <p>Rain Education Consultancy is dedicated to helping students achieve their dreams of studying abroad. Our mission is to provide personalized guidance and support to each student, ensuring they find the right course and university that aligns with their aspirations and career goals.</p>
        </div>
    </div>

    <div class="about-section">
        <div class="about-content">
            <h2>Our History</h2>
            <p>Founded in 2010, Rain Education Consultancy has grown from a small office into one of the most trusted education consultancies in the region. Over the years, we have assisted hundreds of students in realizing their dreams of international education.</p>
        </div>
    </div>

    <div class="about-section">
        <div class="about-content">
            <h2>Our Services</h2>
            <p>We offer a comprehensive range of services including course selection, university application assistance, visa application support, scholarship information, test preparation (IELTS, TOEFL, SAT), career counseling, and accommodation and travel arrangements.</p>
        </div>
    </div>

    <div class="counselling-section">
        <div class="counselling-content">
            <h2>Our Counseling Services</h2>
            <p>We provide expert counseling services to help students make informed decisions about their education and career paths. Our experienced counselors work closely with students to understand their goals and guide them through the process of selecting the right courses and universities.</p>
            <a href="counselling.php">Learn More About Our Counseling Services</a>
        </div>
    </div>


    <div class="testimonials">
        <h2>Success Stories</h2>
        <div class="testimonial">
            <p>"Rain Education Consultancy helped me get into my dream university. Their support throughout the application process was invaluable!" - Sarah K.</p>
        </div>
        <div class="testimonial">
            <p>"Thanks to the team at Rain Education Consultancy, I was able to secure a scholarship and am now studying in the USA." - Michael L.</p>
        </div>
    </div>

    <div class="footer">
        <div class="contact-info">
            <span><i class="fas fa-map-marker-alt"></i> Putalisadak, Kathmandu, Nepal</span>
            <span><i class="fas fa-phone"></i> +977 01 4011052 | +977 01 401745</span>
            <span><i class="fas fa-envelope"></i> info@raineduaction.edu.np</span>
        </div>
    </div>
</body>
</html>