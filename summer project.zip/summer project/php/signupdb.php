<?php
$con = mysqli_connect('localhost','root','','summer_project') ;
if(!$con){
	echo "connection successful";
}
else{
	die(mysqli_error($con));
}
?>