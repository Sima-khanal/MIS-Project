<?php
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $address = $_POST['address'];
    $date = $_POST['date'];
    $message = $_POST['message'];
    $errors = array();
    $con = mysqli_connect('localhost', 'root', '', 'summer_project');

    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    if (empty($name) || empty($email) || empty($mobile) || empty($address) || empty($date) || empty($message)) {
        array_push($errors, "All fields must be filled out!");
    }

    if (!preg_match("/^[a-zA-Z ]*$/", $name)) {
        array_push($errors, "Full name can only contain letters and spaces!");
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        array_push($errors, "Invalid email format!");
    }

    $pattern='/^98\d{8}$/';
    if(!preg_match($pattern, $mobile)){
        array_push($errors, "Invalid phone number!");
    }

    $sql = "SELECT * FROM crud WHERE email ='$email'";
    $result = mysqli_query($con, $sql);
    $rowCount = mysqli_num_rows($result);
    if ($rowCount > 0) {
        array_push($errors, "Email already exists!");
    }

    if (count($errors) > 0) {
        foreach ($errors as $error) {
            echo "<div class='alert alert-danger'>$error</div>";
        }
    } else {
        $sql = "INSERT INTO crud (name, email, mobile, address, date, message) VALUES ('$name','$email','$mobile','$address','$date','$message')";
        if (mysqli_query($con, $sql)) {
            echo "Data inserted successfully";
        } else {
            die(mysqli_error($con));
        }
    }
    mysqli_close($con);
}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Counselling Form</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">

    <style type="text/css">
        body {
            font-family: Arial, sans-serif;
        }

        .banner {
            width: 100%;
            height: 150vh;
            background-image: linear-gradient(rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0.75)), url(../image/first.jpeg);
            background-size: cover;
            background-position: center;
        }

        .navbar {
            width: 85%;
            margin: auto;
            padding: 35px 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .logo {
            width: 150px;
            top: 10px;
            left: 10px;
        }

        .navbar ul li {
            display: inline-block;
            margin: 0 20px;
            position: relative;
        }

        .navbar ul li a {
            text-decoration: none;
            color: white;
            text-transform: uppercase;
        }

        .navbar ul li::after {
            content: '';
            height: 3px;
            width: 0;
            background: seashell;
            position: absolute;
            left: 0;
            bottom: -5px;
            transition: width 0.5s;
        }

        .navbar ul li:hover::after {
            width: 100%;
        }

        .container {
            max-width: 500px;
            margin: 0 auto;
            padding: 80px;
            background-color: orange;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 12px;
        }

        .footer {
            background-color: royalblue;
            color: white;
            padding: 10px;
            text-align: center;
            position: relative;
            width: 100%;
        }

        .footer .contact-info {
            display: flex;
            justify-content: center;
            gap: 20px;
            align-items: center;
            flex-wrap: wrap;
        }

        .footer .contact-info i {
            margin-right: 5px;
        }
    </style>
</head>

<body>
    <div class="banner">
        <div class="navbar">
            <img src="../image/RAIN.png" class="logo">
            <ul>
                <li><a class="active" href="#">HOME</a></li>
                <li><a href="view_course.php">COURSES</a></li>
                <li><a href="aboutus.php">ABOUT US</a></li>
                <li><a href="signup.php">SIGNUP</a></li>
            </ul>
        </div>

        <div class="container my-5">
            <h1>Get a Counselling</h1>

            <form method="post">

                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" placeholder="Enter your full name" name="name">
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="text" class="form-control" placeholder="Enter your email" name="email">
                </div>
                <div class="form-group">
                    <label for="mobile">Mobile</label>
                    <input type="text" class="form-control" placeholder="Enter your mobile number" name="mobile">
                </div>
                <div class="form-group">
                    <label for="address">Address</label>
                    <input type="text" class="form-control" placeholder="Enter your address" name="address">
                </div>
                <div class="form-group">
                    <label for="address">Date</label>
                    <input type="date" class="form-control" name="date" id="date">
                </div>

                <div class="form-group">
                    <label for="message">Message</label>
                    <textarea class="form-control" placeholder="Enter your message" name="message" rows="5"></textarea>
                </div>

                <button type="submit" class="btn btn-primary" name="submit">Submit</button>
                <button type="button" class="btn btn-primary" onclick="window.location.href='index.php'">Back</button>
            </form>
        </div>
    </div>

    <div class="footer">
        <div class="contact-info">
            <span><i class="fas fa-map-marker-alt"></i> Putalisadak, Kathmandu, Nepal</span>
            <span><i class="fas fa-phone"></i> +977 01 4011052 | +977 01 401745</span>
            <span><i class="fas fa-envelope"></i> info@raineduaction.edu.np</span>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var dateInput = document.getElementById('date');
            var today = new Date();
            var year = today.getFullYear();
            var month = String(today.getMonth() + 1).padStart(2, '0');
            var day = String(today.getDate()).padStart(2, '0');
            var minDate = year + '-' + month + '-' + day;
            dateInput.setAttribute('min', minDate);

            // Function to check if a date falls on Saturday
            function isSaturday(date) {
                return date.getDay() === 6;
            }

            // Event listener for date selection
            dateInput.addEventListener('change', function() {
                var selectedDate = new Date(this.value);
                if (isSaturday(selectedDate)) {
                    alert("Bookings are not allowed on Saturdays. Please choose another date.");
                    this.value = "";
                }
            });
        });
    </script>
</body>

</html>
