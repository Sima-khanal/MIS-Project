<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Sidebar</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <style type="text/css">
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: sans-serif;
        }
        li {
            list-style: none;
        }
        a {
            text-decoration: none;
        }
        .sidebar {
            background: red;
            width: 250px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .sidebar .logo-name {
            height: 80px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .sidebar ul {
            padding-left: 0;
        }
        .sidebar li {
            font-size: 18px;
            margin-top: 20px;
            padding: 10px 20px;
            display: flex;
            align-items: center;
            color: white;
        }
        .sidebar li:hover {
            background: #444;
            color: white;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo-name">
            <img src="../image/RAIN.png" class="img-fluid" alt="logo" style="width: 80%;"> 
        </div>
        <ul>
            <li><i class="fas fa-tachometer-alt"></i> Dashboard</li>
            <li><a href="crud_course.php"><i class="fas fa-book"></i> Course</a></li>
            <li><a href="view_student.php"><i class="fas fa-user-graduate"></i> Student</a></li>
            <li><a href="display.php"><i class="fas fa-chalkboard-teacher"></i> Counselor</a></li> 
            <li><a href="crud_teacher.php"><i class="fas fa-chalkboard-teacher"></i> Teacher</a></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li> <!-- Moved Logout to the last -->
        </ul>
    </div>
</body>
</html>