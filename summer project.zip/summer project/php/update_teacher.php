<?php

$errors = [];

if(isset($_GET['t_id'])) {
    $id = $_GET['t_id'];
} else {
    $errors[] = "Update ID is missing.";
}

if(isset($_POST['submit'])) {
    if(empty($_POST['t_id'])) {
        $errors[] = "Teacher ID is missing.";
    } else {
        $t_id = $_POST['t_id'];
    }

    // Connect to the database
    $con = mysqli_connect('localhost', 'root', '', 'summer_project');

    // Check connection
    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $t_name = $_POST['t_name'];
    $t_email = $_POST['t_email'];
    $t_descp = $_POST['t_descp'];
    $t_password = $_POST['t_password'];

    // Prepare and bind the SQL statement
    $stmt = $con->prepare("UPDATE teacher SET t_name=?, t_email=?, t_descp=?, t_password=? WHERE t_id=?");
    $stmt->bind_param("ssssi", $t_name, $t_email, $t_descp, $t_password, $t_id);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Teacher updated successfully";
        header('location:crud_teacher.php');
        exit; // terminate the script after redirection
    } else {
        $errors[] = 'Error updating data: ' . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    mysqli_close($con);
}

if (isset($_GET['t_id'])) {
    $id = $_GET['t_id'];

    $con = mysqli_connect('localhost', 'root', '', 'summer_project') or die('Unable to connect');

    $sql = "SELECT * FROM teacher WHERE t_id = ?";

    // Prepare and bind the SQL statement
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $id);

    // Execute the statement
    if ($stmt->execute()) {
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
        } else {
            $errors[] = "No teacher found with the given ID.";
        }
    } else {
        $errors[] = "Error in query: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    mysqli_close($con);
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Update Teacher</title>
    <!-- Add your CSS and other header content here -->
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> 
    <style type="text/css">
        .h4 {
            height: 100px;
            width: 200px;
        }

        .Login {
            max-width: 500px;
            margin: 0 auto;
            padding: 120px; 
            background-color: orange;
        }

        .form-group {
            margin-bottom: 20px; 
        }
    </style>   
</head>
<body>
     <div class="Login">
         <h4>Update Teacher</h4>
            <?php
            if(!empty($errors)){
                foreach($errors as $err){
                    echo '<span class="error-msg">' . $err . '</span>';
                }
            }
            ?>
       
        <form action="#" method="post" enctype="multipart/form-data">
    <input type="hidden" name="t_id" value="<?php echo isset($_GET['t_id']) ? $_GET['t_id'] : ''; ?>">
    <!-- Other form fields go here -->
    <div class="form-group">
        <input type="text" name="t_name" required placeholder="Name" value="<?php echo isset($row['t_name']) ? $row['t_name'] : ''; ?>">
    </div>
    <div class="form-group">
        <input type="email" name="t_email" required placeholder="Email" value="<?php echo isset($row['t_email']) ? $row['t_email'] : ''; ?>">
    </div>
    <div class="form-group">
        <input type="text" name="t_descp" required placeholder="Description" value="<?php echo isset($row['t_descp']) ? $row['t_descp'] : ''; ?>">
    </div>
    <div class="form-group">
        <input type="password" name="t_password" required placeholder="Password" value="<?php echo isset($row['t_password']) ? $row['t_password'] : ''; ?>">
    </div>
    <div class="form-btn">
        <input type="submit" class="btn btn-primary" value="Update" name="submit">
    </div>
</form>
          
    </div>
</body>
</html>