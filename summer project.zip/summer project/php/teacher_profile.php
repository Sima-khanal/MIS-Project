<?php

session_start();

if (!isset($_SESSION['t_name'])) {
    header('location: teacher.php');
    exit(); 
}

$con = mysqli_connect('localhost', 'root', '', 'summer_project');

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_SESSION['t_id'])) {
    $teacher_id = $_SESSION['t_id'];

   
    $select_teacher = "SELECT t_id, t_name, t_email FROM teacher WHERE t_id='$teacher_id'";
    $result_teacher = mysqli_query($con, $select_teacher);

    if (!$result_teacher) {
        die("Error receiving data: " . mysqli_error($con));
    }

    $teacher = mysqli_fetch_assoc($result_teacher);
} else {
    // If teacher ID is not set in the session, display an error message or handle the situation accordingly
    die("Teacher ID not found in session.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">       
    <title>Teacher Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 50%;
            margin: 50px auto;
            background-color: lightsalmon;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        .teacher-details {
            margin-bottom: 20px;
        }
        .teacher-details p {
            margin: 5px 0;
            color: #666;
        }
        .teacher-details p strong {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Your Profile</h1>
        <div class="teacher-details">
            <p><strong>Teacher ID:</strong> <?php echo $teacher['t_id']; ?></p>
            <p><strong>Username:</strong> <?php echo $teacher['t_name']; ?></p>
            <p><strong>Email:</strong> <?php echo $teacher['t_email']; ?></p>
        </div>
        <a href="teacherdashboard.php" class="btn btn-primary">Back</a>
    </div>
</body>
</html>
