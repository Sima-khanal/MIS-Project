<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Embark on Your Dream: Study Abroad with Us</title>
 <style type="text/css">
   body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 20px;
}

h1 {
  text-align: center;
  font-size: 1.8em;
  margin-bottom: 20px;
}

p {
  text-align: center;
  font-size: 1em;
  margin-bottom: 20px;
}

img {
  display: block;
  margin: 0 auto;
  width: 50%;
  max-width: 600px; /* Adjust max-width as needed */
}

ul {
  list-style: none;
  padding: 0;
  margin: 20px auto;
}

li {
  margin-bottom: 10px;
}



 </style>
</head>
<body>
  <h1>Expand Your Horizons: Pursue Higher Education Abroad</h1>
  <p>Fuel your academic journey and broaden your perspective with our comprehensive study abroad program. We guide aspiring students like you through every step of the process, from initial exploration to successful enrollment in a top-tier university overseas.</p>

  <img src="../image/destination.jpg" alt="World map with highlighted study abroad destinations">

  <h2>Why Study Abroad with Us?</h2>
  <ul>
    <li>Expert Guidance:Benefit from personalized support and guidance from our experienced counselors who specialize in international education.</li>
    <li>Top University Partnerships:Gain access to prestigious universities around the globe, offering a diverse range of academic programs.</li>
    <li>Streamlined Application Process: We simplify the application process, ensuring a smooth transition to your dream university.</li>
    <li>Cultural Immersion:Experience a new culture, language, and way of life, enriching your personal and academic development.</li>
  </ul>

</body>
</html>
