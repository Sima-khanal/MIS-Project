<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['s_name'])) {
    // Redirect the user to the login page or display an error message
    header('location: signup.php');
    exit(); // Stop script execution after redirect
}
$con = mysqli_connect('localhost','root','','summer_project') ;

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if user ID is set in the session
if (isset($_SESSION['s_id'])) {
    $user_id = $_SESSION['s_id'];

    // Fetch user details from the database
    $select_user = "SELECT id, full_name, email FROM users WHERE id='$user_id'";
    $result_user = mysqli_query($con, $select_user);

    if (!$result_user) {
        die("Error receiving data: " . mysqli_error($con));
    }

    // Fetch user details as an associative array
    $user = mysqli_fetch_assoc($result_user);
} else {
    // If user ID is not set in the session, display an error message or handle the situation accordingly
    die("User ID not found in session.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">       
    <title>User Profile</title>
    <style>
         <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 50%;
            margin: 50px auto;
            background-color: lightsalmon;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        .user-details {
            margin-bottom: 20px;
        }
        .user-details p {
            margin: 5px 0;
            color: #666;
        }
        .user-details p strong {
            margin-right: 10px;
        }
    </style>
    </style>
</head>
<body>
    <div class="container">
        <h1>Your Profile</h1>
        <div class="user-details">
            <p><strong>User ID:</strong> <?php echo $user['id']; ?></p>
            <p><strong>Username:</strong> <?php echo $user['full_name']; ?></p>
            <p><strong>Email:</strong> <?php echo $user['email']; ?></p>
        </div>
          <a href="userdashboard.php" class="btn btn-primary">Back</a>
    </div>

</body>
</html>
