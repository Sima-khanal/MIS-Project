<?php
session_start();

if (!isset($_SESSION['s_name'])) {
    header('location: signup.php');
    exit();
}

$con = mysqli_connect('localhost','root','','summer_project');
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$user_id = $_SESSION['s_id'];

// Show success message after cancellation, if any
$success_message = '';
if (isset($_GET['msg'])) {
    $success_message = $_GET['msg'];
}

// Handle form submission for updating user details
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $new_name = mysqli_real_escape_string($con, $_POST['full_name']);
    $new_email = mysqli_real_escape_string($con, $_POST['email']);

    $update_sql = "UPDATE users SET full_name='$new_name', email='$new_email' WHERE id='$user_id'";
    if (mysqli_query($con, $update_sql)) {
        $success_message = "Profile updated successfully.";
    } else {
        $error_message = "Error updating profile: " . mysqli_error($con);
    }
}

// Fetch user details (fresh from DB after possible update)
$select_user = "SELECT id, full_name, email FROM users WHERE id='$user_id'";
$result_user = mysqli_query($con, $select_user);

if (!$result_user) {
    die("Error receiving data: " . mysqli_error($con));
}

$user = mysqli_fetch_assoc($result_user);

// Fetch courses user enrolled in
$courses_sql = "SELECT e.enroll_id, e.course_name, e.fee, e.status, e.s_date, e.e_date, c.course_url
                FROM enroll e
                LEFT JOIN course c ON e.course_id = c.course_id
                WHERE e.id = '$user_id'";
$courses_result = mysqli_query($con, $courses_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>User Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0; padding: 20px;
        }
        .profile-container {
            max-width: 700px;
            margin: 0 auto 50px;
            background-color: white;
            padding: 20px 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1, h2 {
            color: #333;
            margin-bottom: 20px;
        }
        .form-control {
            margin-bottom: 15px;
        }
        .courses-table img {
            width: 100px;
            height: 70px;
            object-fit: cover;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<div class="profile-container">
    <h1>Your Profile</h1>

    <?php if (!empty($success_message)): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success_message) ?></div>
    <?php elseif (!empty($error_message)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error_message) ?></div>
    <?php endif; ?>

    <form method="post" action="">
        <input type="hidden" name="update_profile" value="1" />
        <label for="full_name" class="form-label">Full Name</label>
        <input type="text" name="full_name" id="full_name" class="form-control" required
               value="<?php echo htmlspecialchars($user['full_name']); ?>" />

        <label for="email" class="form-label">Email</label>
        <input type="email" name="email" id="email" class="form-control" required
               value="<?php echo htmlspecialchars($user['email']); ?>" />

        <button type="submit" class="btn btn-primary">Update Profile</button>
    </form>
</div>

<div class="profile-container">
    <h2>Your Enrolled Courses</h2>

    <?php if (mysqli_num_rows($courses_result) > 0): ?>
        <table class="table table-striped courses-table">
            <thead>
                <tr>
                    <th>Course Image</th>
                    <th>Course Name</th>
                    <th>Fee (Rs.)</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($course = mysqli_fetch_assoc($courses_result)): ?>
                <?php $status = strtolower($course['status']); ?>
                <tr>
                    <td>
                        <?php if (!empty($course['course_url'])): ?>
                            <img src="../image/<?php echo htmlspecialchars($course['course_url']); ?>" alt="Course Image" />
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </td>
                    <td><?php echo htmlspecialchars($course['course_name']); ?></td>
                    <td><?php echo htmlspecialchars($course['fee']); ?></td>
                    <td><?php echo htmlspecialchars($course['s_date']); ?></td>
                    <td><?php echo htmlspecialchars($course['e_date']); ?></td>
                    <td>
                        <?php
                            if ($status == 'enrolled') {
                                echo '<span class="badge bg-success">Enrolled</span>';
                            } elseif ($status == 'pending') {
                                echo '<span class="badge bg-warning text-dark">Pending</span>';
                            } else {
                                echo htmlspecialchars($course['status']);
                            }
                        ?>
                    </td>
                    <td>
                        <?php if ($status !== 'completed'): ?>
                            <a href="delete_enrollment.php?enroll_id=<?php echo $course['enroll_id']; ?>" 
                               class="btn btn-danger btn-sm"
                               onclick="return confirm('Are you sure you want to cancel this enrollment?');">
                               Cancel
                            </a>
                        <?php else: ?>
                            <span class="text-success">Completed</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>You have not enrolled in any courses yet.</p>
    <?php endif; ?>
</div>

</body>
</html>
