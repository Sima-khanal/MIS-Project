<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Payment Success</title>
	<style>
		body {
			font-family: Arial, sans-serif;
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
			height: 100vh;
			margin: 0;
			background-color: #f0f8ff;
		}
		h1 {
			color: #4CAF50;
			font-size: 2.5em;
			margin-bottom: 20px;
		}
		a {
			color: white;
			background-color: black;
			padding: 10px 20px;
			text-decoration: none;
			border-radius: 5px;
			font-size: 1em;
		}
		a:hover {
			background-color: crimson;
		}
	</style>
</head>
<body>
	<h1>Payment Fail</h1>
	<a href="userdashboard.php">Home</a>
</body>
</html>