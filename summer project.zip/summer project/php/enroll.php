<?php
// Display errors for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['s_name'])) {
    header('Location: sigin.php');
    exit();
}

$conn = mysqli_connect('localhost', 'root', '', 'summer_project');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$product = null;
$invoice = null;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['product_id'], $_POST['price'], $_POST['product_name'], $_POST['s_date'],$_POST['e_date'])) {
        $product_id = mysqli_real_escape_string($conn, $_POST['product_id']);
        $cid = $_SESSION['s_id']; // Assuming you have a customer ID in the session
        $total = mysqli_real_escape_string($conn, $_POST['price']) ;
        $s_date=  $_POST['s_date'];
          $e_date=  $_POST['e_date'];

        $sql = "SELECT * FROM course WHERE course_id='$product_id'";
        $result = mysqli_query($conn, $sql);

        if ($result && mysqli_num_rows($result) == 1) {
            $product = mysqli_fetch_assoc($result);

            $invoice = $product_id . time();
            $pname = mysqli_real_escape_string($conn, $product['name']);
            $price = $product['fee'];

            $insert = "INSERT INTO `enroll` (course_name, fee,s_date,e_date,invoice_no,course_id,id) VALUES ('$pname', '$price', '$s_date', '$e_date', '$invoice', '$product_id', '$cid')";
            if (!mysqli_query($conn, $insert)) {
                die('Error: ' . mysqli_error($conn));
            } 
        } else {
            die('Error fetching product: ' . mysqli_error($conn));
        }
    } else {
        die('Required POST variables not set');
    }
}
mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Product Order</title>
    <style type="text/css">
        body {
            font-family: Arial, sans-serif;
            background-color: orange;
            color:lightcyan;
            margin: 0;
            padding: 0;
        }
        .item img {
            height: 200px;
            width: 220px;
        }
        .inpt {
            width: 80px;
            padding: 10px;
            margin-top: 0px;
            border: 1px solid #000;
            color: #000;
        }
        form {
            margin: 20px;
            padding: 40px;
            width: 300px;
            background-color: orangered;
            border: 1px solid #000;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .quantity-controls button {
            background-color: #dc143c;
            color: #fff;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
        }
        .quantity-controls button:hover {
            background-color: #a10f2d;
        }
        .quantity-controls input {
            text-align: center;
        }
        input[type="submit"] {
            background-color: lightgreen;
            color: green;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            margin-top: 10px;
        }
        input[type="submit"]:hover {
            background-color: #a10f2d;
        }
        label {
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }
    </style>
</head>
<body>


<form action="https://uat.esewa.com.np/epay/main" method="POST">
    <div class="item">
        <?php 
        if ($product) {
            echo "<img src='../image/{$product['course_url']}'/>";
            echo "<p>{$product['name']}</p>";
            echo "<p>RS. {$product['fee']}</p>";
        } else {
            echo "<p>Product not found.</p>";
        }
        ?>
    </div>


    <input type="hidden" name="cid" value="<?php echo htmlspecialchars($_SESSION['s_id']); ?>">
    <input type="hidden" name="p_id" value="<?php echo htmlspecialchars($product['course_id']); ?>"><br>
    
    <label>Total</label><br>
    <input class="inpt" type="text" name="tAmt" id="total" value="<?php echo htmlspecialchars($product['fee']); ?>" readonly>
    <input value="<?php echo htmlspecialchars($product['fee']); ?>" name="amt" type="hidden">
    <input value="0" name="txAmt" type="hidden">
    <input value="0" name="psc" type="hidden">
    <input value="0" name="pdc" type="hidden">
    <input value="epay_payment" name="scd" type="hidden">
    <input value="<?php echo htmlspecialchars($invoice); ?>" name="pid" type="hidden">
    <input value="http://localhost/summer%20project/php/esewa_success.php" type="hidden" name="su">
    <input value="http://localhost/summer%20project/php/failed.php" type="hidden" name="fu">
    <br>
    <label>Pay With</label><br>
    <input style="height: 50px; cursor: pointer;" type="image" src="../image/esewaa.png">
</form>

<script>
function updateTotal() {
    var quantity = document.getElementById('quantity').value;
    var initialPrice = <?php echo $product['price']; ?>;
    var total = quantity * initialPrice;
    document.getElementById('total').value = total;
    document.getElementsByName('amt')[0].value = total;
}

function incrementQuantity() {
    var quantityInput = document.getElementById('quantity');
    quantityInput.value = parseInt(quantityInput.value) + 1;
    updateTotal();
}

function decrementQuantity() {
    var quantityInput = document.getElementById('quantity');
    if (parseInt(quantityInput.value) > 1) {
        quantityInput.value = parseInt(quantityInput.value) - 1;
        updateTotal();
    }
}
</script>

</body>
</html>