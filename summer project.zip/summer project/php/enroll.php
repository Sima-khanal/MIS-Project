<?php
session_start();

if (!isset($_SESSION['s_name'])) {
    header('Location: sigin.php');
    exit();
}

$conn = mysqli_connect('localhost', 'root', '', 'summer_project');
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$product = null;
$invoice = null;

// Check if form submitted from course list page
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['product_id'], $_POST['price'], $_POST['product_name'], $_POST['s_date'], $_POST['e_date'])) {
        $product_id = mysqli_real_escape_string($conn, $_POST['product_id']);
        $cid = $_SESSION['s_id']; // logged-in user id
        $s_date = $_POST['s_date'];
        $e_date = $_POST['e_date'];

        // Fetch course info from DB (to get full data like course_url etc)
        $sql = "SELECT * FROM course WHERE course_id='$product_id'";
        $result = mysqli_query($conn, $sql);

        if ($result && mysqli_num_rows($result) == 1) {
            $product = mysqli_fetch_assoc($result);

            // Generate invoice number (unique)
            $invoice = $product_id . time();

            // Insert enrollment with status 'Pending'
            $insert_sql = "INSERT INTO enroll (course_name, fee, s_date, e_date, invoice_no, course_id, id, status) 
                           VALUES (
                              '".mysqli_real_escape_string($conn, $product['name'])."',
                              '".mysqli_real_escape_string($conn, $product['fee'])."',
                              '".mysqli_real_escape_string($conn, $s_date)."',
                              '".mysqli_real_escape_string($conn, $e_date)."',
                              '".mysqli_real_escape_string($conn, $invoice)."',
                              '".mysqli_real_escape_string($conn, $product_id)."',
                              '".mysqli_real_escape_string($conn, $cid)."',
                              'Pending'
                           )";
            if (!mysqli_query($conn, $insert_sql)) {
                die('Enrollment insert failed: ' . mysqli_error($conn));
            }
        } else {
            die('Product not found');
        }
    } else {
        die('Required POST variables not set');
    }
} else {
    die('Invalid request');
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Payment - Khalti</title>
    <script src="https://khalti.com/static/khalti-checkout.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: orange;
            color: lightcyan;
            padding: 20px;
        }
        .item img {
            width: 220px;
            height: 200px;
        }
        label {
            font-weight: bold;
            display: block;
            margin-top: 10px;
        }
        button {
            margin-top: 20px;
            padding: 12px 20px;
            background-color: #5A31F4;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
            border-radius: 5px;
        }
        button:hover {
            background-color: #401bb8;
        }
    </style>
</head>
<body>

<h2>Confirm Payment for: <?php echo htmlspecialchars($product['name']); ?></h2>

<div class="item">
    <img src="../image/<?php echo htmlspecialchars($product['course_url']); ?>" alt="Product Image"/>
    <p><?php echo htmlspecialchars($product['name']); ?></p>
    <p>RS. <?php echo htmlspecialchars($product['fee']); ?></p>
</div>

<button id="payment-button">Pay with Khalti</button>

<script>
    var config = {
        // Use your Khalti public test key here
        "publicKey": "test_public_key_XXXXXXXXXXXX",  
        "productIdentity": "<?php echo $invoice; ?>",  // unique invoice number
        "productName": "<?php echo addslashes($product['name']); ?>",
        "productUrl": window.location.href,
        "eventHandler": {
            onSuccess (payload) {
                // Send payload to server for verification
                fetch('khalti_verify.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                }).then(response => response.json())
                .then(data => {
                    if(data.status === 'success'){
                        alert('Payment Successful!');
                        window.location.href = 'success.php';  // Redirect to your success page
                    } else {
                        alert('Payment verification failed: ' + data.message);
                    }
                })
                .catch(error => {
                    alert('Payment verification error: ' + error);
                });
            },
            onError (error) {
                console.error(error);
                alert('Payment failed or cancelled.');
            },
            onClose () {
                console.log('Payment widget closed');
            }
        },
        "paymentPreference": ["KHALTI", "EBANKING","MOBILE_BANKING","CONNECT_IPS","SCT"]
    };

    var checkout = new KhaltiCheckout(config);
    document.getElementById('payment-button').onclick = function () {
        // Khalti expects amount in paisa (multiply by 100)
        checkout.show({amount: <?php echo intval($product['fee'] * 100); ?>});
    }
</script>

</body>
</html>
