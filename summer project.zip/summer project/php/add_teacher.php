<?php

$errors = [];

if(isset($_POST['submit'])){
    $t_name = $_POST['t_name'];
    $t_email = $_POST['t_email'];
    $t_descp = $_POST['t_descp'];
    $t_password = $_POST['t_password'];

    if(empty($t_name) || empty($t_email) || empty($t_descp) || empty($t_password)) {
        $errors[] = 'All fields are required.';
    }

    if(empty($errors)) {
        $con = mysqli_connect('localhost', 'root', '', 'summer_project');

        if (!$con) {
            die("Connection failed: " . mysqli_connect_error());
        }
        $t_password_hashed = md5($t_password);
        
        $sql = "INSERT INTO teacher (t_name, t_email, t_descp, t_password) 
                VALUES ('$t_name', '$t_email', '$t_descp', '$t_password_hashed')";

        if (mysqli_query($con, $sql)) {
            echo "Teacher added successfully";
        } else {
            $errors[] = 'Error inserting data: ' . mysqli_error($con);
        }

        mysqli_close($con);
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add Teacher</title>
    <style type="text/css">
        .container {
            max-width: 500px;
            height: 400px;
            margin: 0 auto;
            padding: 20px; 
            background-color: orange;
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px; 
        }

        .btn-primary {
            display: inline-block;
            padding: 10px 20px;
            margin-top: 20px;
            text-decoration: none;
            color: #fff;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        .error-msg {
            color: red;
        }
    </style>
</head>
<body>
    <div class="container">     
        <form action="#" method="post">
            <h4>Add Teacher</h4>
            <?php
                if(isset($errors)){
                    foreach($errors as $err){
                        echo '<span class="error-msg">' . $err . '</span>';
                    }
                }
            ?>
            <div class="form-group">
                <input type="text" name="t_name" required placeholder="Name">
            </div>
            <div class="form-group">
                <input type="email" name="t_email" required placeholder="Email">
            </div>
            <div class="form-group">
                <input type="text" name="t_descp" required placeholder="Description">
            </div>
            <div class="form-group">
                <input type="password" name="t_password" required placeholder="Password">
            </div>
            <div class="form-btn">
                <input type="submit" class="btn-primary" value="ADD" name="submit">
            </div>          
        </form>
         <a href="adminpage.php" class="btn-primary">Back</a>
    </div>

</body>
</html>
