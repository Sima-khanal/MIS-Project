
<?php

$errors = [];

if(isset($_GET['updateid'])) {
    $id = $_GET['updateid'];
} else {
    $errors[] = "Update ID is missing.";
}

if(isset($_POST['submit'])) {
    if(empty($_POST['course_id'])) {
        $errors[] = "Course ID is missing.";
    } else {
        $course_id = $_POST['course_id'];
    }

    // Connect to the database
    $con = mysqli_connect('localhost', 'root', '', 'summer_project');

    // Check connection
    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $name = $_POST['name'];
    $fee = $_POST['fee'];
    $description = $_POST['description'];

    // Check if a file is selected for upload
    if(isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $image = $_FILES['image']['name'];
        $image_temp = $_FILES['image']['tmp_name'];
        $image_folder = '../image/' . $image;
    } else {
        // No file selected or error in file upload
        $image = ''; // Assign empty string to image
    }
    $stmt = $con->prepare("UPDATE course SET name=?, fee=?, course_desp=?, course_url=? WHERE course_id=?");
    $stmt->bind_param("sdsdi", $name, $fee, $description, $image, $course_id);

    // Execute the statement
    if ($stmt->execute()) {
        if(!empty($image)) {
            move_uploaded_file($image_temp, $image_folder);
        }
        echo "Course updated successfully";
        header('location:crud_course.php');
        exit; 
    } else {
        $errors[] = 'Error updating data: ' . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    mysqli_close($con);
}

if (isset($_GET['course_id'])) {
    $id = $_GET['course_id'];

    $con = mysqli_connect('localhost', 'root', '', 'summer_project') or die('Unable to connect');

    $sql = "SELECT * FROM course WHERE course_id = ?";

    // Prepare and bind the SQL statement
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $id);

    // Execute the statement
    if ($stmt->execute()) {
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
        } else {
            $errors[] = "No course found with the given ID.";
        }
    } else {
        $errors[] = "Error in query: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    mysqli_close($con);
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Update Course</title>
    <!-- Add your CSS and other header content here -->
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> 
    <style type="text/css">
        .h4 {
            height: 100px;
            width: 200px;
        }

    .Login {
        max-width: 500px;
        margin: 0 auto;
        padding: 120px; 
        background-color: orange;
    }

    .form-group {
        margin-bottom: 20px; 
    }
</style>   
</head>
<body>
    <!-- Your HTML form goes here -->
     <div class="Login">
         <h4>Update Course</h4>
            <?php
            if(!empty($errors)){
                foreach($errors as $err){
                    echo '<span class="error-msg">' . $err . '</span>';
                }
            }
            ?>

    <form action="#" method="post" enctype="multipart/form-data">
<input type="hidden" name="course_id" value="<?php echo isset($_GET['course_id']) ? $_GET['course_id'] : ''; ?>">
<!-- Other form fields go here -->
<div class="form-group">
    <input type="file" name="image" placeholder="Image">
</div>
<div class="form-group">
    <input type="text" name="name" required placeholder="Name" value="<?php echo isset($row['name']) ? $row['name'] : ''; ?>">
</div>
<div class="form-group">
    <input type="text" name="fee" required placeholder="Fee" value="<?php echo isset($row['fee']) ? $row['fee'] : ''; ?>">
</div>
<div class="form-group">
    <input type="text" name="description" required placeholder="Description" value="<?php echo isset($row['course_desp']) ? $row['course_desp'] : ''; ?>">
</div>
<div class="form-btn">
    <input type="submit" class="btn btn-primary" value="Update" name="submit">
</div>
</form>

</div>
</body>
</html>  