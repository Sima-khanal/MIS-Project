<?php
$con = mysqli_connect('localhost','root','','summer_project') ;
if(!$con){
  die("connection fAILED: ". mysqli_connect_error());
}
if(isset($_GET['deleteid'])) { 
  //  $id=$_POST['id'];
  // $sql="DELETE from `student` WHERE id='$id'";
  // $result=mysqli_query($conn,$sql);
  // if($result){echo "data deleted";}else{echo "not deleted";}
    
     $id=$_GET['deleteid'] ;

$sql="DELETE FROM users where id='$id'";
$result=mysqli_query($con,$sql);

  if($result){
    if (mysqli_affected_rows($con)==1) {
      header('location:view_student.php');
      exit;
    }else{
      echo "no record were deletd";
    }
  }
    else{
      echo "Error: ". mysqli_error($con);
    }
    
    
    
    }?>