<?php
// khalti_verify.php

header('Content-Type: application/json');
$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['token']) || !isset($data['amount']) || !isset($data['idx'])) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
    exit();
}

$token = $data['token'];
$amount = $data['amount'];  // amount in paisa
$productId = $data['idx'];  // invoice_no

$secret_key = "test_secret_key_XXXXXXXXXXXX";  // Replace with your Khalti secret key

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://khalti.com/api/v2/payment/verify/");
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
    'token' => $token,
    'amount' => $amount
]));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Authorization: Key $secret_key"
]);

$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);

if (isset($result['idx']) && $result['idx'] == $productId) {
    // Payment verified, update your DB status
    $conn = mysqli_connect('localhost', 'root', '', 'summer_project');
    if (!$conn) {
        echo json_encode(['status' => 'error', 'message' => 'DB connection error']);
        exit();
    }

    $invoice_no = mysqli_real_escape_string($conn, $productId);
    $update_sql = "UPDATE enroll SET status='Enrolled' WHERE invoice_no='$invoice_no'";
    if (mysqli_query($conn, $update_sql)) {
        echo json_encode(['status' => 'success', 'message' => 'Payment verified']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'DB update failed']);
    }
    mysqli_close($conn);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Payment verification failed']);
}
