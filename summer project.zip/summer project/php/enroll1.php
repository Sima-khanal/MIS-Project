<?php 
session_start();
if (!isset($_SESSION['s_name'])) {
    header('location:signup.php');
}
$con = mysqli_connect('localhost', 'root', '', 'summer_project');

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$course_id = $_GET['course_id'];
$select = "SELECT * FROM course WHERE course_id='$course_id'";
$result = mysqli_query($con, $select);

if (!$result) {
    die("Error receiving data: " . mysqli_error($con));
}

$data = mysqli_fetch_assoc($result);

if (isset($_POST['submit'])) {
    $c_id = $_POST['c_id'];
    $u_id = $_POST['u_id'];
    $course = $_POST['course'];
    $fee = $_POST['fee'];
    $s_date = $_POST['s_date'];
    $e_date = $_POST['e_date'];

    if (empty($s_date) || empty($e_date)) {
        echo '<script>alert("Please fill in all required fields.");</script>';
    } else {
        $insert = "INSERT INTO enroll (course_name, fee, s_date, e_date, course_id, id) 
                   VALUES ('$course', '$fee', '$s_date', '$e_date', '$c_id', '$u_id')";
        if (mysqli_query($con, $insert)) {
            echo '<script>alert("Enrolled Successfully");</script>';
            echo '<meta http-equiv="refresh" content="0;url=userdashboard.php"/>';
            exit();
        } else {
            echo "Error while Enrolling: " . mysqli_error($con);
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Enroll Page</title>
    <style type="text/css">
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        form {
            background-color: orangered;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
            width: 40%;
            max-width: 400px;
        }

        form input[type="hidden"] {
            display: none;
        }

        form label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        form input[type="text"],
        form input[type="date"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        form input[type="submit"] {
            display: inline-block;
            width: 100%;
            padding: 15px;
            background-color: lightblue;
            color: royalblue;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
        }

        form input[type="submit"]:hover {
            background-color: blue;
        }
    </style>
</head>
<body>
    <form method="post">
        <input type="hidden" name="c_id" value="<?php echo $data['course_id']; ?>"><br>
        <input type="hidden" name="u_id" value="<?php echo $_SESSION['s_id']; ?>"><br>
        <label>Enroll Course</label><br>
        <input type="text" name="course" value="<?php echo $data['name']; ?>" readonly><br>
        <label>Fee</label><br>
        <input type="text" name="fee" value="<?php echo $data['fee']; ?>" readonly><br>
        <label>Start Date</label><br>
        <input type="date" name="s_date" id="start-date" required><br>
        <label>End Date</label><br>
        <input type="date" name="e_date" id="end-date" required><br>
        <input type="submit" name="submit" value="Enroll">
    </form>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var startDateInput = document.getElementById('start-date');
            var endDateInput = document.getElementById('end-date');
            var today = new Date();
            var year = today.getFullYear();
            var month = String(today.getMonth() + 1).padStart(2, '0');
            var day = String(today.getDate()).padStart(2, '0');
            var minDate = year + '-' + month + '-' + day;
            startDateInput.setAttribute('min', minDate);

            // Function to check if a date falls on Saturday
            function isSaturday(date) {
                return date.getDay() === 6;
            }

            // Event listener for start date selection
            startDateInput.addEventListener('change', function() {
                var selectedDate = new Date(this.value);
                if (isSaturday(selectedDate)) {
                    alert("We can't enroll on Saturdays. Please choose another date.");
                    this.value = "";
                    endDateInput.value = "";
                    return;
                }
              
                var endDate = new Date(selectedDate);
                endDate.setDate(endDate.getDate() + 90);
                var endYear = endDate.getFullYear();
                var endMonth = String(endDate.getMonth() + 1).padStart(2, '0');
                var endDay = String(endDate.getDate()).padStart(2, '0');
                endDateInput.value = endYear + '-' + endMonth + '-' + endDay;
            });
        });
    </script>
</body>
</html>
