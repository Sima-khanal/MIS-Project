<?php

$con = mysqli_connect('localhost', 'root', '', 'summer_project');

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT t_name, t_email, t_descp FROM teacher";
$result = mysqli_query($con, $sql);

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>View Teachers</title>
    <style type="text/css">
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h4 {
            text-align: left;
            margin-bottom: 20px;
        }
        .teacher-info {
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #ddd;
            background-color: #f9f9f9;
        }
        .teacher-info p {
            margin: 5px 0;
        }
        .btn-primary {
            display: inline-block;
            padding: 10px 20px;
            text-decoration: none;
            color: #fff;
            background-color: #007bff;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>View Teachers</h2>
        <?php
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<div class='teacher-info'>";
                echo "<p><strong>Name:</strong> " . $row['t_name'] . "</p>";
                echo "<p><strong>Email:</strong> " . $row['t_email'] . "</p>";
                echo "<p> " . $row['t_descp'] . "</p>";
          
                echo "</div>";
            }
        } else {
            echo "<p>No data found</p>";
        }
        ?>
    </div>
</body>
</html>

<?php
// Close the database connection
mysqli_close($con);
?>
