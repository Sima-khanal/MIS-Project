<?php
$id = $_GET['updateid'];
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $address = $_POST['address'];
    $date = $_POST['date'];
    $message = $_POST['message'];
    $errors = array();
    $con = mysqli_connect('localhost', 'root', '', 'summer_project');

    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $sql = "UPDATE crud SET name='$name', email='$email', mobile='$mobile', address='$address', date='$date', message='$message' WHERE id='$id'";

    if (mysqli_query($con, $sql)) {
        header('location: display.php');
            exit;
    } else {
        die(mysqli_error($con));
    }

    mysqli_close($con);
}

if (isset($_GET['updateid'])) {
    $id = $_GET['updateid'];

    $con = mysqli_connect('localhost', 'root', '', 'summer_project') or die('Unable to connect');

    $sql = "SELECT * FROM crud WHERE id = '$id'";

    $result = mysqli_query($con, $sql);

    if ($result) {
        $row = mysqli_fetch_assoc($result);
    } else {
        echo "Error in query: " . mysqli_error($con);
    }

    mysqli_close($con);
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Update Record</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <style type="text/css">
        .h1 {
            height: 100px;
            width: 200px;
        }

        .container {
            max-width: 500px;
            margin: 0 auto;
            padding: 120px;
            background-color: orange;
        }

        .form-group {
            margin-bottom: 30px;
        }
    </style>
</head>

<body>
    <div class="container my-5">
        <h1>Get a Counselling</h1>
        <form method="post">
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" placeholder="Enter your full name" name="name" value="<?php echo $row['name']; ?>" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="text" class="form-control" placeholder="Enter your email" name="email" value="<?php echo $row['email']; ?>" required>
            </div>
            <div class="form-group">
                <label for="mobile">Mobile</label>
                <input type="text" class="form-control" placeholder="Enter your mobile number" name="mobile" value="<?php echo $row['mobile']; ?>" required>
            </div>
            <div class="form-group">
                <label for="address">Address</label>
                <input type="text" class="form-control" placeholder="Enter your address" name="address" value="<?php echo $row['address']; ?>" required>
            </div>
            <div class="form-group">
                <label for="address">Date</label>
                <input type="date" class="form-control" placeholder="Enter your date" name="date" value="<?php echo $row['date']; ?>" required>
            </div>
            <div class="form-group">
                <label for="address">Message</label>
                <input type="text" class="form-control" placeholder="Enter your message" name="message" value="<?php echo $row['message']; ?>" required>
            </div>
            <button type="submit" class="btn btn-primary" name="submit">Update</button>
        </form>
    </div>
</body>

</html>