<?php
$con = mysqli_connect('localhost', 'root', '', 'summer_project');

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Initialize the search query variable
$search_query = isset($_GET['search']) ? mysqli_real_escape_string($con, $_GET['search']) : '';

$sql = "SELECT * FROM crud WHERE name LIKE '%$search_query%'";
$result = mysqli_query($con, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CRUD Operation</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <style>
        .btn-update {
            background-color: #007bff;
            color: white;
        }
        .btn-update:hover {
            background-color: #0056b3;
            color: white;
        }
        .btn-delete {
            background-color: #dc3545;
            color: white;
        }
        .btn-delete:hover {
            background-color: #bd2130;
            color: white;
        }
        .sidebar {
            min-width: 20px;
            max-width: 200px;
            background-color: #f8f9fa;
            padding: 15px;
        }
        .content {
            margin-left: 0px;
            padding: 15px;
        }
        .container-fluid {
            padding-top: 20px;
        }
    </style>
</head>
<body>
<div class="d-flex">
    <!-- Include Sidebar -->
    <?php include 'sidebar.php'; ?>

    <!-- Main Content -->
    <div class="content">
        <div class="container-fluid">
            <h1 class="my-4">Registered for Counselling List</h1>
            <div class="d-flex justify-content-between align-items-center mb-4">
                <form class="d-flex" method="GET" action="">
                    <input class="form-control me-2" type="text" name="search" placeholder="Search by Student Name" value="<?php echo htmlspecialchars($search_query); ?>">
                    <button class="btn btn-primary" type="submit">Search</button>
                </form>
       
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Serial Number</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Mobile</th>
                        <th scope="col">Address</th>
                        <th scope="col">Date</th>
                        <th scope="col">Message</th>
                        <th scope="col">Operation</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result) {    
                        while ($row = mysqli_fetch_assoc($result)) {
                            $id = $row['id'];
                            $name = $row['name'];
                            $email = $row['email'];
                            $mobile = $row['mobile'];
                            $address = $row['address'];
                            $date = $row['date'];
                            $message = $row['message'];
                            echo '<tr>
                                  <th scope="row">'.$id.'</th>
                                  <td>'.$name.'</td>
                                  <td>'.$email.'</td>
                                  <td>'.$mobile.'</td>
                                  <td>'.$address.'</td>
                                  <td>'.$date.'</td>
                                  <td>'.$message.'</td>
                                  <td>
                                    <a href="update.php?updateid='.$id.'" class="btn btn-update text-light me-2">Update</a>
                                    <a href="delete_coun.php?deleteid='.$id.'" class="btn btn-delete text-light">Delete</a>
                                  </td>
                                  </tr>';
                        }
                    }
                    ?>
                </tbody>
            </table>
            
        <a href="adminpage.php" class="btn btn-primary">Back</a>
        </div>
    </div>
</div>
</body>
</html>
