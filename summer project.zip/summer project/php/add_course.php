<?php 

$errors = [];

if(isset($_POST['submit'])){
    $image = $_FILES['image']['name'];
    $name = $_POST['name'];
    $fee = $_POST['fee'];
    $Course_description=$_POST['description'];
    $image_temp = $_FILES['image']['tmp_name'];
    $image_folder = '../image/' . $image;

    if(empty($name) || empty($fee)) {
        $errors[] = 'All fields are required.';
    }
    if ($fee < 1) {
            $errors[] = 'fee can not be less than 1!';
        }
    if(empty($errors)) {
        $con = mysqli_connect('localhost', 'root', '', 'summer_project');

        if (!$con) {
            die("Connection failed: " . mysqli_connect_error());
        }
       
        $sql1 = "INSERT INTO course (course_url, name, fee, course_desp) 
                 VALUES ('$image', '$name', '$fee',' $Course_description')";

        if (mysqli_query($con, $sql1)) {
            move_uploaded_file($image_temp, $image_folder);
            echo "Course inserted successfully";
            // header("Location: index.php");
            // exit();
        } else {
            $errors[] = 'Error inserting data: ' . mysqli_error($con);
        }
    

        mysqli_close($con);
    }
}

?> 

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> 
    <style type="text/css">
        .h4 {
            height: 100px;
            width: 200px;
        }

.Login {
    max-width: 500px;
    margin: 0 auto;
    padding: 120px; 
    background-color: orange;
}

.form-group {
    margin-bottom: 20px; 
}
    </style>   

</head>
<body>
    <div class="Login">
     
<form action="#" method="post"  enctype="multipart/form-data">
    <h4>Add course</h4>
    <?php
        if(isset($errors)){
            foreach($errors as $err){
                echo '<span class="error-msg">' . $err . '</span>';
            }
        }
    ?>
    <div class="form-group">
    <input type="file" name="image" required placeholder="Image">
    </div>
    <div class="form-group">
    <input type="text" name="name" required placeholder="Name">
    </div>
    <div class="form-group">
    <input type="text" name="fee" required placeholder="Fee">
    </div>
    <div class="form-group">
    <input type="text" name="description" required placeholder="description">
    </div>
    <div class="form-btn">
    <input type="submit" class="btn btn-primary" value="ADD" name="submit">
     <a href="adminpage.php" class="btn btn-primary">Back</a>
</div>
</form>
    </div>

</body>
</html>