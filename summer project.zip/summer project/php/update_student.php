<?php
$id=$_GET['updateid'];
if (isset($_POST['submit'])) {
    $name = $_POST['fullname'];
    $email = $_POST['email'];
    $password= $_POST['password'];
    $passwordHash =md5($password);
 
    $errors=array();
    $con = mysqli_connect('localhost', 'root', '', 'summer_project');

    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }
    $sql = "UPDATE users set id=$id,full_name='$name',email='$email',password='$passwordHash' WHERE id='$id'";
    $result=mysqli_query($con,$sql);
    if (($result)) {
       echo "Updated successfully";
       header('location:view_student.php');
    } else {
        die(mysqli_error($con));
    }
// }
    mysqli_close($con);
}
if (isset($_GET['updateid'])) {
    $id = $_GET['updateid'];

    $con = mysqli_connect('localhost', 'root', '', 'summer_project') or die('Unable to connect');

    $sql = "SELECT * FROM users WHERE id = '$id'";

    $result = mysqli_query($con, $sql);

    if ($result) {
        $row = mysqli_fetch_assoc($result);
    } else {
        echo "Error in query: " . mysqli_error($con);
    }

    mysqli_close($con);
}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">

    <style type="text/css">
        
        .container {
            max-width: 500px;
            margin: 0 auto;
            padding: 120px;
            background-color: orange;
        } 
         .h1 {
            height: 200px;
            width: 300px;
        }

        .form-group {
            margin-bottom: 30px;
        }
    </style>
</head>

<body>
    <div class="container my-5">
        <h1>Upadte Student </h1>
        <form method="post">
            <div class="form-group">
                <input type="text" class="form-control" name="fullname" placeholder="Full Name:">
            </div>
            <div class="form-group">
                <input type="email"  class="form-control" name="email" placeholder="Email:">
            </div>
            <div class="form-group">
                <input type="password"  class="form-control" name="password" placeholder="Password:">
            </div>
            <div class="form-group">
                <input type="text"  class="form-control" name="repeat_password" placeholder="Repeat Password:">
            </div>
            <div class="form-btn">
                <input type="submit" class="btn btn-primary"  name="submit">
            </div>

         

        </form>

    </div>
</body>

</html>