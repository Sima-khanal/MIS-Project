<?php 
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>View Courses</title>
    <style>
        /* Basic styling */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f7f7f7; 
        }

        .course {
            width: calc(33.33% - 20px); 
            border: 1px solid #ccc;
            margin-bottom: 20px;
            padding: 20px;
            background-color: #fff;
            display: inline-block;
            vertical-align: top;
            box-sizing: border-box;
        }

        .course img {
            max-width: 100%;
            height: auto;
            margin-top: 10px;
        }

      
        .course-name {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .course-details p {
            margin: 5px 0;
        }

        .course-description {
            margin-top: 10px;
        }

        form label {
            font-weight: bold;
            display: block;
            margin-top: 10px;
        }

        input[type="date"] {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4CAF50; /* Button background color */
            color: white; /* Button text color */
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049; /* Button hover color */
        }

    </style>
</head>
<body>
    <?php
    $con = mysqli_connect('localhost', 'root', '', 'summer_project');

    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $sql = "SELECT * FROM course";
    $result = mysqli_query($con, $sql);
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo '<div class="course">';
            echo '<p class="course-name">' . $row["name"] . '</p>';
            echo '<p>Fee: ' . $row["fee"] . '</p>';
            echo '<p class="course-details">Course: ' . $row["course_desp"] . '</p>';
            echo '<img src="../image/' . $row['course_url'] . '" alt="Course Image">';
            ?>

            <form method="post" action="enroll.php">
                <input type="hidden" name="product_id" value="<?php echo $row['course_id']; ?>">
                <input type="hidden" name="price" value="<?php echo $row['fee']; ?>">
                <input type="hidden" name="product_name" value="<?php echo $row['name']; ?>">
                <label>Start Date</label>
                <input type="date" name="s_date" class="start-date" required>
                <label>End Date</label>
                <input type="date" name="e_date" class="end-date" required>
                <input type="submit" name="submit" value="Enroll">
            </form>

            <?php
            echo '</div>'; // Close course div
        }
    } else {
        echo "No courses found";
    }

    mysqli_close($con);
    ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var startDateInputs = document.querySelectorAll('.start-date');
            var endDateInputs = document.querySelectorAll('.end-date');
            var today = new Date();
            var year = today.getFullYear();
            var month = String(today.getMonth() + 1).padStart(2, '0');
            var day = String(today.getDate()).padStart(2, '0');
            var minDate = year + '-' + month + '-' + day;

            startDateInputs.forEach(function(startDateInput, index) {
                var endDateInput = endDateInputs[index];
                startDateInput.setAttribute('min', minDate);

                // Function to check if a date falls on Saturday
                function isSaturday(date) {
                    return date.getDay() === 6;
                }

                // Event listener for start date selection
                startDateInput.addEventListener('change', function() {
                    var selectedDate = new Date(this.value);
                    if (isSaturday(selectedDate)) {
                        alert("We can't enroll on Saturdays. Please choose another date.");
                        this.value = "";
                        endDateInput.value = "";
                        return;
                    }

                    var endDate = new Date(selectedDate);
                    endDate.setDate(endDate.getDate() + 90);
                    var endYear = endDate.getFullYear();
                    var endMonth = String(endDate.getMonth() + 1).padStart(2, '0');
                    var endDay = String(endDate.getDate()).padStart(2, '0');
                    endDateInput.value = endYear + '-' + endMonth + '-' + endDay;
                });
            });
        });
    </script>
</body>
</html>