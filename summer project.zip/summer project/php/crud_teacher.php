<?php
// include 'sidebar.php';
// Function to fetch all teachers
function getTeachers($con) {
    $sql = "SELECT * FROM teacher";
    $result = mysqli_query($con, $sql);

    $teachers = [];

    if ($result && mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
            $teachers[] = $row;
        }
    }

    return $teachers;
}

$con = mysqli_connect('localhost', 'root', '', 'summer_project');
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>View Teachers</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> 
    <style type="text/css">
        .h4 {
            height: 100px;
            width: 200px;
        }

        .Login {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px; 
            background-color: white;
        }

        .form-group {
            margin-bottom: 20px; 
        }

        .btn-group {
            display: flex;
            align-items: center;
        }

        .btn-group .btn {
            margin-right: 5px;
        }
          a.btn.btn-primary {
        display: inline-block;
        padding: 10px 20px;
        margin-left: 20px;
        text-decoration: none;
        color: white;
        background-color: blue;
        border: none;
        border-radius: 5px;
        transition: background-color 0.3s;
    }

    a.btn.btn-primary:hover {
        background-color: white;
        color: black;
    }
    </style>   
</head>
<body>
    <div class="Login">
        <h4>Teachers</h4>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Description</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $teachers = getTeachers($con);
                foreach($teachers as $teacher) {
                    echo "<tr>";
                    echo "<td>" . (isset($teacher['t_id']) ? $teacher['t_id'] : '') . "</td>";
                    echo "<td>" . (isset($teacher['t_name']) ? $teacher['t_name'] : '') . "</td>";
                    echo "<td>" . (isset($teacher['t_email']) ? $teacher['t_email'] : '') . "</td>";
                    echo "<td>" . (isset($teacher['t_descp']) ? $teacher['t_descp'] : '') . "</td>";
                    echo "<td class='btn-group'>
                            <button class='btn btn-primary'><a href='update_teacher.php?t_id=" . (isset($teacher['t_id']) ? $teacher['t_id'] : '') . "' class='text-light'>Update</a></button>
                            <button class='btn btn-danger'><a href='delete_teacher.php?deleteid=" . (isset($teacher['t_id']) ? $teacher['t_id'] : '') . "' class='text-light'>Delete</a></button>
                          </td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
     <a href="adminpage.php" class="btn btn-primary">Back</a>
</body>
</html>

<?php
mysqli_close($con);
?>